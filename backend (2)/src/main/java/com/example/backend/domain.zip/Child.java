package com.example.backend.domain;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "child")
public class Child {

    // 컬럼
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String birth;

    @Column(nullable = false, unique = true)
    private String loginId;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String name;

    private String profileImage;

    private Integer phoneNumber;

    private String information;

    @Column(nullable = false)
    private Boolean gender;

    private String status;

    private String school;

    private Boolean wantToTakeRequest;

    private String comment;

    private Integer feelScore00;

    private Integer feelScore01;

    private String feelScore02;
    private String feelScore03;
    private String feelScore04;
    private String feelScore05;
    private String feelScore06;
    private String feelScore07;
    private String feelScore08;
    private String feelScore09;
    private String feelScore10;
    private String feelScore11;
    private String feelScore12;
    private String feelScore13;
    private String feelScore14;
    private String feelScore15;
    private String feelScore16;
    private String feelScore17;
    private String feelScore18;
    private String feelScore19;
    private String feelScore20;
    private String feelScore21;
    private String feelScore22;
    private String feelScore23;

    // 부모와의 관계 (다대일)
//    @ManyToOne
//    @JoinColumn(name = "parent_id")
//    private Parent parent;

    // 아이 특성 관련 (다대다)
    @ManyToMany(mappedBy = "child", cascade = CascadeType.ALL)
    @JoinTable(name = "personalityLink",
    joinColumns = @JoinColumn(name="child_id"),
    inverseJoinColumns = @JoinColumn(name="personality_id"))
    private List<Personality> personalityList = new ArrayList<>();

    // LLM 진단 결과 (일대다)
    @OneToMany(mappedBy = "child", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Summary> summaryList = new ArrayList<>();

    // 아이 키워드 (일대다)
    @OneToMany (mappedBy = "child", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ChildKeyWord> childKeyWordList = new ArrayList<>();

//    // 아이 심리 보고서 (일대다)
//    @OneToMany(mappedBy = "child", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<ChildMe  = "child", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<ProfessionalAreaLink> professionalAreaLinkList = new ArrayList<>();
//
//    // 상담 분석 리스트 (일대다)
//    @OneToMany(mappedBy = "child", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<Analysis> analysisList = new ArrayList<>();


    // 생성자
    protected Child(){}

}
