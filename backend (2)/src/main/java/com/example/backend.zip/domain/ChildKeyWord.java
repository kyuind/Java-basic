package com.example.backend.domain;

import jakarta.persistence.*;

@Entity
@Table(name = "childKeyWord")
public class ChildKeyWord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "chattingID", length = 100, nullable = false)
    private String chattingID;

    @Column(name = "keyWord")
    private String keyWord;

    @Column(name = "kind")
    private String kind;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "childID", nullable = false)
    private Child child;

    protected ChildKeyWord(){}



}
