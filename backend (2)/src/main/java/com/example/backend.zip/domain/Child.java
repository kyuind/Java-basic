package com.example.backend.domain;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "child")
public class Child {

    // 컬럼
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String birth;

    @Column(nullable = false, unique = true)
    private String loginId;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String name;

    private String profileImage;

    private Integer phoneNumber;

    private String information;

    @Column(nullable = false)
    private Boolean gender;

    private String status;

    private String school;

    private Boolean wantToTakeRequest;

    private String comment;

    private Integer feelScore00;

    private Integer feelScore01;

    private Integer feelScore02;
    private Integer feelScore03;
    private Integer feelScore05;
    private Integer feelScore06;
    private Integer feelScore07;
    private Integer feelScore04;
    private Integer feelScore08;
    private Integer feelScore09;
    private Integer feelScore10;
    private Integer feelScore11;
    private Integer feelScore12;
    private Integer feelScore13;
    private Integer feelScore14;
    private Integer feelScore15;
    private Integer feelScore16;
    private Integer feelScore17;
    private Integer feelScore18;
    private Integer feelScore19;
    private Integer feelScore20;
    private Integer feelScore21;
    private Integer feelScore22;
    private Integer feelScore23;

    // 부모와의 관계 (다대일)
//    @ManyToOne
//    @JoinColumn(name = "parent_id")
//    private Parent parent;

    // 아이 특성 관련 (다대다)
    @ManyToMany(mappedBy = "child", cascade = CascadeType.ALL)
    @JoinTable(name = "personalityLink",
    joinColumns = @JoinColumn(name="child_id"),
    inverseJoinColumns = @JoinColumn(name="personality_id"))
    private List<Personality> personalityList = new ArrayList<>();

    // LLM 진단 결과 (일대다)
    @OneToMany(mappedBy = "child", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Summary> summaryList = new ArrayList<>();

    // 아이 키워드 (일대다)
    @OneToMany (mappedBy = "child", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ChildKeyWord> childKeyWordList = new ArrayList<>();

//    // 아이 심리 보고서 (일대다)
//    @OneToMany(mappedBy = "child", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<ChildMe>  = "child", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<ProfessionalAreaLink> professionalAreaLinkList = new ArrayList<>();
//
//    // 상담 분석 리스트 (일대다)
//    @OneToMany(mappedBy = "child", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<Analysis> analysisList = new ArrayList<>();


    // 생성자
    protected Child(){}

}
