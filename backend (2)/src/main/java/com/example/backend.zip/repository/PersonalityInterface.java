package com.example.backend.repository;

import com.example.backend.domain.Personality;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonalityInterface extends JpaRepository<Personality, Long> {

}
