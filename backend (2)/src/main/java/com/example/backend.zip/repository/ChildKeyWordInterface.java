package com.example.backend.repository;

import com.example.backend.domain.ChildKeyWord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChildKeyWordInterface extends JpaRepository<ChildKeyWord, Long> {
}
