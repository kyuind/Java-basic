package com.example.backend.service;

import com.example.backend.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ChildService {
    private final ChildInterface childInterface;
    private final ChildKeyWordInterface childKeyWordInterface;
    private final SummaryInterface summaryInterface;
    private final PersonalityInterface personalityInterface;

    public ChildService(ChildInterface childInterface, ChildKeyWordInterface childKeyWordInterface, SummaryInterface summaryInterface, PersonalityInterface personalityInterface) {
        this.childInterface = childInterface;
        this.childKeyWordInterface = childKeyWordInterface;
        this.summaryInterface = summaryInterface;
        this.personalityInterface = personalityInterface;
    }

    @Transactional
//    1. Child에 있는 정보
//    2. Child id로 keyword 정보
//    3. Child id로 summary 정보
//    4. Child id로 personality 정보

}
