package com.example.backend.dto.response;

public class ChildTotalGetDTOResponse {
    private ChildToKeywordDTOResponse childToKeywordDTOResponse;
    private AllChildDTOResponse allChildDTOResponse;
    private ChildToPersonalityDTOResponse childToPersonalityDTOResponse;
    private ChildToSummaryDTOResponse childToSummaryDTOResponse;


    public ChildTotalGetDTOResponse(ChildToKeywordDTOResponse childToKeywordDTOResponse, AllChildDTOResponse allChildDTOResponse, ChildToPersonalityDTOResponse childToPersonalityDTOResponse, ChildToSummaryDTOResponse childToSummaryDTOResponse) {
        this.childToKeywordDTOResponse = childToKeywordDTOResponse;
        this.allChildDTOResponse = allChildDTOResponse;
        this.childToPersonalityDTOResponse = childToPersonalityDTOResponse;
        this.childToSummaryDTOResponse = childToSummaryDTOResponse;
    }

    public ChildToKeywordDTOResponse getChildToKeywordDTOResponse() {
        return childToKeywordDTOResponse;
    }

    public AllChildDTOResponse getAllChildDTOResponse() {
        return allChildDTOResponse;
    }

    public ChildToPersonalityDTOResponse getChildToPersonalityDTOResponse() {
        return childToPersonalityDTOResponse;
    }

    public ChildToSummaryDTOResponse getChildToSummaryDTOResponse() {
        return childToSummaryDTOResponse;
    }
}
